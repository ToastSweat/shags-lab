from __future__ import annotations

import dataclasses
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
import unittest
import urllib.parse


PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR))

from r34_tag_watcher import (  # noqa: E402
    ApiError,
    Archive,
    Rule34Api,
    Settings,
    StateDatabase,
    WatchedTag,
    load_settings,
    sanitize_component,
    verify_hard_link_support,
)


class FakeApi:
    def __init__(self, posts_by_tag=None, pages_by_tag=None):
        self.posts_by_tag = posts_by_tag or {}
        self.pages_by_tag = pages_by_tag or {}
        self.download_count = 0

    def fetch_posts(self, watched):
        return list(self.posts_by_tag.get(watched.tag, []))

    def fetch_posts_page(self, watched, page):
        pages = self.pages_by_tag.get(watched.tag)
        if pages is not None:
            return list(pages[page]) if page < len(pages) else []
        return list(self.posts_by_tag.get(watched.tag, [])) if page == 0 else []

    def download_to(self, url, destination):
        self.download_count += 1
        destination.write_bytes(b"fake-image-data")


def make_settings(output_directory: Path, watched_tags=()) -> Settings:
    return Settings(
        output_directory=output_directory,
        api_base_url="https://api.rule34.xxx/index.php",
        api_user_id="123",
        api_key="secret",
        watched_tags=tuple(watched_tags),
        results_per_page=100,
        pages_per_check=3,
        first_run_download_limit_per_tag=2,
        max_downloads_per_tag_per_run=100,
        request_delay_seconds=1.0,
        request_timeout_seconds=45,
        retry_attempts=3,
        allowed_extensions=(".jpg", ".png"),
        save_sidecar_metadata=False,
    )


def post(post_id: int, tags: str = "series character artist"):
    return {
        "id": str(post_id),
        "tags": tags,
        "file_url": f"https://cdn.example.test/images/{post_id}.jpg",
        "md5": f"{post_id:032x}",
    }


class ConfigurationTests(unittest.TestCase):
    def test_sanitize_windows_folder_names(self):
        self.assertEqual(sanitize_component('bad:name*here.'), "bad_name_here")
        self.assertEqual(sanitize_component("CON"), "_CON")
        self.assertEqual(sanitize_component("normal_tag"), "normal_tag")

    def test_load_settings_deduplicates_tags_within_category(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "config.json"
            path.write_text(
                json.dumps(
                    {
                        "output_directory": str(Path(temp) / "archive"),
                        "watched_tags": {
                            "copyright": ["series", "SERIES"],
                            "character": ["hero"],
                            "artist": [],
                        },
                        "downloads": {"allowed_extensions": [".jpg"]},
                    }
                ),
                encoding="utf-8",
            )
            settings = load_settings(path)
            self.assertEqual(
                settings.watched_tags,
                (WatchedTag("copyright", "series"), WatchedTag("character", "hero")),
            )

    def test_load_settings_rejects_credential_url_fragments(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "config.json"
            path.write_text(
                json.dumps(
                    {
                        "output_directory": str(Path(temp) / "archive"),
                        "api": {"user_id": "user_id=123", "api_key": "&api_key=secret"},
                        "watched_tags": {},
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "numeric user ID"):
                load_settings(path)

    def test_api_url_contains_tag_page_and_optional_credentials(self):
        with tempfile.TemporaryDirectory() as temp:
            settings = make_settings(Path(temp))
            api = Rule34Api(settings, logging.getLogger("test-url"))
            parsed = urllib.parse.urlparse(api.build_posts_url("some_tag", 2))
            query = urllib.parse.parse_qs(parsed.query)
            self.assertEqual(query["tags"], ["some_tag"])
            self.assertEqual(query["pid"], ["2"])
            self.assertEqual(query["json"], ["1"])
            self.assertEqual(query["user_id"], ["123"])
            self.assertEqual(query["api_key"], ["secret"])

    def test_api_surfaces_plain_json_string_message(self):
        with tempfile.TemporaryDirectory() as temp:
            api = Rule34Api(make_settings(Path(temp)), logging.getLogger("test-message"))
            with self.assertRaisesRegex(ApiError, "authentication required"):
                api._decode_posts_response(json.dumps("authentication required").encode("utf-8"))

    def test_api_accepts_double_encoded_post_list(self):
        with tempfile.TemporaryDirectory() as temp:
            api = Rule34Api(make_settings(Path(temp)), logging.getLogger("test-double-json"))
            inner = json.dumps([post(7)])
            decoded = api._decode_posts_response(json.dumps(inner).encode("utf-8"))
            self.assertEqual(decoded[0]["id"], "7")

    def test_api_treats_no_images_message_as_empty_result(self):
        with tempfile.TemporaryDirectory() as temp:
            api = Rule34Api(make_settings(Path(temp)), logging.getLogger("test-empty"))
            decoded = api._decode_posts_response(json.dumps("No images found").encode("utf-8"))
            self.assertEqual(decoded, [])

    def test_output_volume_supports_hard_links(self):
        with tempfile.TemporaryDirectory() as temp:
            verify_hard_link_support(Path(temp) / "archive")


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.logger = logging.getLogger(f"test-archive-{id(self)}")
        self.logger.addHandler(logging.NullHandler())

    def tearDown(self):
        self.temp.cleanup()

    def test_one_network_download_is_hard_linked_to_two_matching_folders(self):
        copyright_tag = WatchedTag("copyright", "series")
        character_tag = WatchedTag("character", "character")
        settings = make_settings(self.root, (copyright_tag, character_tag))
        fake_api = FakeApi()

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            first = archive.process_post(post(42), copyright_tag)
            second = archive.process_post(post(42), character_tag)

        copyright_files = list((self.root / "Copyright" / "series").glob("*.jpg"))
        character_files = list((self.root / "Character" / "character").glob("*.jpg"))
        self.assertEqual(fake_api.download_count, 1)
        self.assertEqual(first.downloaded, 1)
        self.assertEqual(first.linked, 1)
        self.assertEqual(second.downloaded, 0)
        self.assertEqual(second.linked, 1)
        self.assertEqual(len(copyright_files), 1)
        self.assertEqual(len(character_files), 1)
        self.assertTrue(os.path.samefile(copyright_files[0], character_files[0]))
        canonical_files = list((self.root / ".r34-watcher" / "files").glob("*/*.jpg"))
        self.assertEqual(len(canonical_files), 1)
        self.assertTrue(os.path.samefile(canonical_files[0], copyright_files[0]))

    def test_missing_tag_link_is_repaired_without_another_download(self):
        watched = WatchedTag("artist", "artist")
        fake_api = FakeApi({"artist": [post(42)]})
        settings = make_settings(self.root, (watched,))

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            first = archive.process_tag(watched)
            tag_file = next((self.root / "Artist" / "artist").glob("*.jpg"))
            tag_file.unlink()
            second = archive.process_tag(watched)

        repaired = list((self.root / "Artist" / "artist").glob("*.jpg"))
        self.assertEqual(first.downloaded, 1)
        self.assertEqual(second.downloaded, 0)
        self.assertEqual(second.linked, 1)
        self.assertEqual(fake_api.download_count, 1)
        self.assertEqual(len(repaired), 1)

    def test_overlapping_backfill_posts_use_one_physical_file(self):
        character = WatchedTag("character", "hero")
        general = WatchedTag("general", "blue_hair")
        shared = post(88, "hero blue_hair")
        fake_api = FakeApi(pages_by_tag={"hero": [[shared]], "blue_hair": [[shared]]})
        settings = make_settings(self.root, (character, general))

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            summary = archive.run(backfill=True)

        character_file = next((self.root / "Character" / "hero").glob("*.jpg"))
        general_file = next((self.root / "General" / "blue_hair").glob("*.jpg"))
        self.assertEqual(summary.downloaded, 1)
        self.assertEqual(summary.linked, 2)
        self.assertEqual(fake_api.download_count, 1)
        self.assertTrue(os.path.samefile(character_file, general_file))

    def test_general_tag_downloads_to_general_folder(self):
        watched = WatchedTag("general", "blue_hair")
        settings = make_settings(self.root, (watched,))
        fake_api = FakeApi()

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            result = archive.process_post(post(73), watched)

        files = list((self.root / "General" / "blue_hair").glob("*.jpg"))
        self.assertEqual(result.downloaded, 1)
        self.assertEqual(fake_api.download_count, 1)
        self.assertEqual(len(files), 1)

    def test_first_check_limits_downloads_and_baselines_older_posts(self):
        watched = WatchedTag("artist", "artist")
        posts = [post(number) for number in range(10, 0, -1)]
        fake_api = FakeApi({"artist": posts})
        settings = make_settings(self.root, (watched,))

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            first = archive.process_tag(watched)
            second = archive.process_tag(watched)

            count = state.connection.execute(
                "SELECT COUNT(*) FROM tag_posts WHERE category = ? AND watched_tag = ?",
                (watched.category, watched.tag),
            ).fetchone()[0]

        self.assertEqual(first.downloaded, 2)
        self.assertEqual(first.skipped_baseline, 8)
        self.assertEqual(second.downloaded, 0)
        self.assertEqual(fake_api.download_count, 2)
        self.assertEqual(count, 10)

    def test_later_check_downloads_only_new_post(self):
        watched = WatchedTag("artist", "artist")
        fake_api = FakeApi({"artist": [post(10), post(9)]})
        settings = make_settings(self.root, (watched,))

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            archive.process_tag(watched)
            fake_api.posts_by_tag["artist"] = [post(11), post(10), post(9)]
            second = archive.process_tag(watched)

        self.assertEqual(second.downloaded, 1)
        self.assertEqual(fake_api.download_count, 3)

    def test_backfill_downloads_posts_previously_marked_as_baseline(self):
        watched = WatchedTag("artist", "artist")
        posts = [post(number) for number in range(10, 0, -1)]
        fake_api = FakeApi({"artist": posts}, {"artist": [posts]})
        settings = make_settings(self.root, (watched,))

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            first = archive.process_tag(watched)
            backfill = archive.backfill_tag(watched)
            statuses = {
                row[0]: row[1]
                for row in state.connection.execute(
                    "SELECT post_id, status FROM tag_posts WHERE category = ? AND watched_tag = ?",
                    (watched.category, watched.tag),
                )
            }

        self.assertEqual(first.downloaded, 2)
        self.assertEqual(first.skipped_baseline, 8)
        self.assertEqual(backfill.downloaded, 8)
        self.assertEqual(backfill.already_processed, 2)
        self.assertEqual(fake_api.download_count, 10)
        self.assertNotIn("baseline_skipped", statuses.values())

    def test_backfill_walks_multiple_pages_and_is_safe_to_rerun(self):
        watched = WatchedTag("character", "hero")
        page_one = [post(6), post(5), post(4)]
        page_two = [post(3), post(2), post(1)]
        fake_api = FakeApi(pages_by_tag={"hero": [page_one, page_two, []]})
        settings = dataclasses.replace(
            make_settings(self.root, (watched,)), results_per_page=3
        )

        with StateDatabase(self.root / "state.sqlite3") as state:
            archive = Archive(settings, state, fake_api, self.logger)
            first = archive.backfill_tag(watched)
            second = archive.backfill_tag(watched)

        self.assertEqual(first.downloaded, 6)
        self.assertEqual(second.downloaded, 0)
        self.assertEqual(second.already_processed, 6)
        self.assertEqual(fake_api.download_count, 6)


if __name__ == "__main__":
    unittest.main()
