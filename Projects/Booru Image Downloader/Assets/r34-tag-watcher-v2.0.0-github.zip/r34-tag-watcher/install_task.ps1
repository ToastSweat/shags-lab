[CmdletBinding()]
param(
    [ValidateRange(0, 10080)]
    [int]$IntervalMinutes = 0,

    [string]$TaskName = "Rule34 Tag Watcher"
)

$ErrorActionPreference = "Stop"
$ProjectDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $ProjectDirectory "r34_tag_watcher.py"
$ConfigPath = Join-Path $ProjectDirectory "config.json"

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "config.json does not exist. Run setup.ps1 first."
}

if ($IntervalMinutes -eq 0) {
    $Config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
    $IntervalMinutes = [int]$Config.schedule.interval_minutes
}
if ($IntervalMinutes -lt 15) {
    throw "The scheduled interval must be at least 15 minutes."
}

$Launcher = Get-Command "py.exe" -ErrorAction SilentlyContinue
if ($null -ne $Launcher) {
    $Execute = $Launcher.Source
    $Arguments = "-3 `"$ScriptPath`" --config `"$ConfigPath`""
} else {
    $Python = Get-Command "python.exe" -ErrorAction SilentlyContinue
    if ($null -eq $Python) {
        throw "Python 3 was not found. Install it from python.org and retry."
    }
    $Execute = $Python.Source
    $Arguments = "`"$ScriptPath`" --config `"$ConfigPath`""
}

$Action = New-ScheduledTaskAction `
    -Execute $Execute `
    -Argument $Arguments `
    -WorkingDirectory $ProjectDirectory

$Trigger = New-ScheduledTaskTrigger `
    -Once `
    -At (Get-Date).AddMinutes(2) `
    -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) `
    -RepetitionDuration (New-TimeSpan -Days 3650)

$Settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Hours 2) `
    -MultipleInstances IgnoreNew

$CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$Principal = New-ScheduledTaskPrincipal `
    -UserId $CurrentUser `
    -LogonType Interactive `
    -RunLevel Limited

Register-ScheduledTask `
    -TaskName $TaskName `
    -Description "Downloads new Rule34.xxx posts matching configured copyright, character, artist, and general tags." `
    -Action $Action `
    -Trigger $Trigger `
    -Settings $Settings `
    -Principal $Principal `
    -Force | Out-Null

Write-Host "Scheduled task '$TaskName' installed for every $IntervalMinutes minute(s)." -ForegroundColor Green
Write-Host "It runs while $CurrentUser is logged in."
