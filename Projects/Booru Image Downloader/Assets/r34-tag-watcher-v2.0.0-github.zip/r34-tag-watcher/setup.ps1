[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$ProjectDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ProjectDirectory "config.json"

function Read-WithDefault {
    param(
        [Parameter(Mandatory = $true)][string]$Prompt,
        [Parameter(Mandatory = $true)][string]$Default
    )
    $Value = Read-Host "$Prompt [$Default]"
    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $Default
    }
    return $Value.Trim()
}

function Convert-ToTagArray {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) {
        return @()
    }
    return @(
        $Value.Split(",") |
            ForEach-Object { $_.Trim() } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            Select-Object -Unique
    )
}

function Find-Python {
    $Launcher = Get-Command "py.exe" -ErrorAction SilentlyContinue
    if ($null -ne $Launcher) {
        return @{ Execute = $Launcher.Source; PrefixArguments = @("-3") }
    }
    $Python = Get-Command "python.exe" -ErrorAction SilentlyContinue
    if ($null -ne $Python) {
        return @{ Execute = $Python.Source; PrefixArguments = @() }
    }
    throw "Python 3 was not found. Install Python 3 from python.org, then run setup.ps1 again."
}

Write-Host ""
Write-Host "Rule34 Tag Watcher setup" -ForegroundColor Cyan
Write-Host "Use exact site tag names, including underscores. Separate multiple tags with commas."
Write-Host "The download folder must be on an NTFS drive so duplicate matches can use hard links."
Write-Host ""

$DefaultPictures = [Environment]::GetFolderPath("MyPictures")
if ([string]::IsNullOrWhiteSpace($DefaultPictures)) {
    $DefaultPictures = Join-Path $env:USERPROFILE "Pictures"
}
$DefaultOutput = Join-Path $DefaultPictures "Rule34 Tag Archive"
$OutputDirectory = Read-WithDefault -Prompt "Download folder" -Default $DefaultOutput
$CopyrightTags = Convert-ToTagArray (Read-Host "Copyright tags")
$CharacterTags = Convert-ToTagArray (Read-Host "Character tags")
$ArtistTags = Convert-ToTagArray (Read-Host "Artist tags")
$GeneralTags = Convert-ToTagArray (Read-Host "General tags")
$IntervalText = Read-WithDefault -Prompt "Check every how many minutes?" -Default "60"

$IntervalMinutes = 0
if (-not [int]::TryParse($IntervalText, [ref]$IntervalMinutes) -or $IntervalMinutes -lt 15) {
    throw "The scheduled interval must be a whole number of at least 15 minutes."
}

Write-Host ""
Write-Host "Enter only the credential values--do not include user_id=, api_key=, &, or = prefixes."
$ApiUserId = (Read-Host "Rule34 numeric user ID").Trim()
if ($ApiUserId -notmatch '^\d+$') {
    throw "The Rule34 user ID must contain numbers only."
}
$SecureApiKey = Read-Host "Rule34 API key value (input is hidden)" -AsSecureString
$ApiKeyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureApiKey)
try {
    $ApiKey = ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($ApiKeyPointer)).Trim()
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ApiKeyPointer)
}
if ([string]::IsNullOrWhiteSpace($ApiKey) -or $ApiKey -match '(?i)api_key=|user_id=|&') {
    throw "Enter only the API key value, without parameter names, ampersands, or prefixes."
}

$Config = [ordered]@{
    output_directory = $OutputDirectory
    api = [ordered]@{
        base_url = "https://api.rule34.xxx/index.php"
        user_id = $ApiUserId
        api_key = $ApiKey
    }
    watched_tags = [ordered]@{
        copyright = @($CopyrightTags)
        character = @($CharacterTags)
        artist = @($ArtistTags)
        general = @($GeneralTags)
    }
    schedule = [ordered]@{
        interval_minutes = $IntervalMinutes
    }
    scan = [ordered]@{
        results_per_page = 100
        pages_per_check = 3
        first_run_download_limit_per_tag = 25
        max_downloads_per_tag_per_run = 100
        request_delay_seconds = 1.0
        request_timeout_seconds = 45
        retry_attempts = 3
    }
    downloads = [ordered]@{
        allowed_extensions = @(".jpg", ".jpeg", ".png", ".gif", ".webp")
        save_sidecar_metadata = $false
    }
}

$Config | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
$PythonInfo = Find-Python
$ValidationArguments = @($PythonInfo.PrefixArguments) + @(
    (Join-Path $ProjectDirectory "r34_tag_watcher.py"),
    "--config",
    $ConfigPath,
    "--check-config"
)
& $PythonInfo.Execute @ValidationArguments
if ($LASTEXITCODE -ne 0) {
    throw "The generated configuration did not pass validation."
}

& (Join-Path $ProjectDirectory "install_task.ps1") -IntervalMinutes $IntervalMinutes

Write-Host ""
Write-Host "Setup complete." -ForegroundColor Green
Write-Host "The download drive supports hard links. Run run_now.bat once to test the API."
Write-Host "Configuration: $ConfigPath"
Write-Host "Downloads:     $OutputDirectory"
