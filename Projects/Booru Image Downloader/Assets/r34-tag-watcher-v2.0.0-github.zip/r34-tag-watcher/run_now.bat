@echo off
setlocal
cd /d "%~dp0"

where py.exe >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 "%~dp0r34_tag_watcher.py" --config "%~dp0config.json" --verbose
) else (
    python "%~dp0r34_tag_watcher.py" --config "%~dp0config.json" --verbose
)
set "WATCHER_EXIT=%ERRORLEVEL%"

echo.
if %WATCHER_EXIT% EQU 0 (
    echo Watcher finished successfully.
) else (
    echo Watcher finished with an error. Check logs\watcher.log.
)
pause
endlocal & exit /b %WATCHER_EXIT%
