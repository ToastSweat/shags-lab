@echo off
setlocal
cd /d "%~dp0"

echo This will scan and download the complete available history for every configured tag.
echo Each post is stored once and hard-linked into every matching tag folder.
echo Existing files will be skipped, and an interrupted backfill can be run again safely.
echo This may take a long time for popular tags.
echo.
choice /M "Start historical backfill"
if %ERRORLEVEL% NEQ 1 (
    echo Backfill cancelled.
    pause
    exit /b 0
)

where py.exe >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 "%~dp0r34_tag_watcher.py" --config "%~dp0config.json" --backfill --verbose
) else (
    python "%~dp0r34_tag_watcher.py" --config "%~dp0config.json" --backfill --verbose
)
set "WATCHER_EXIT=%ERRORLEVEL%"

echo.
if %WATCHER_EXIT% EQU 0 (
    echo Historical backfill finished successfully.
) else (
    echo Backfill stopped with an error. It is safe to run this file again.
    echo Check logs\watcher.log for details.
)
pause
endlocal & exit /b %WATCHER_EXIT%
