#!/usr/bin/env python3
"""Periodically archive Rule34.xxx posts matching selected tags.

This project intentionally uses only the Python standard library so it can be
unpacked and scheduled on a normal Windows installation without pip.
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sqlite3
import tempfile
import time
from typing import Any, Mapping, Sequence
import urllib.error
import urllib.parse
import urllib.request


VERSION = "2.0.0"
PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG = PROJECT_DIR / "config.json"
CATEGORY_NAMES = {
    "copyright": "Copyright",
    "character": "Character",
    "artist": "Artist",
    "general": "General",
}
WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}
DEFAULT_ALLOWED_EXTENSIONS = (".jpg", ".jpeg", ".png", ".gif", ".webp")


class ConfigurationError(ValueError):
    """Raised for configuration that cannot be used safely."""


class ApiError(RuntimeError):
    """Raised when the remote API cannot provide a usable response."""


@dataclasses.dataclass(frozen=True)
class WatchedTag:
    category: str
    tag: str

    @property
    def category_folder(self) -> str:
        return CATEGORY_NAMES[self.category]


@dataclasses.dataclass(frozen=True)
class Settings:
    output_directory: Path
    api_base_url: str
    api_user_id: str
    api_key: str
    watched_tags: tuple[WatchedTag, ...]
    results_per_page: int
    pages_per_check: int
    first_run_download_limit_per_tag: int
    max_downloads_per_tag_per_run: int
    request_delay_seconds: float
    request_timeout_seconds: float
    retry_attempts: int
    allowed_extensions: tuple[str, ...]
    save_sidecar_metadata: bool


@dataclasses.dataclass
class RunSummary:
    downloaded: int = 0
    linked: int = 0
    skipped_baseline: int = 0
    skipped_extension: int = 0
    already_processed: int = 0
    errors: int = 0

    def absorb(self, other: "RunSummary") -> None:
        for field in dataclasses.fields(self):
            setattr(self, field.name, getattr(self, field.name) + getattr(other, field.name))


def _as_mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ConfigurationError(f"'{name}' must be a JSON object.")
    return value


def _bounded_int(value: Any, name: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool):
        raise ConfigurationError(f"'{name}' must be a number.")
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"'{name}' must be a whole number.") from exc
    if not minimum <= parsed <= maximum:
        raise ConfigurationError(f"'{name}' must be between {minimum} and {maximum}.")
    return parsed


def _bounded_float(value: Any, name: str, minimum: float, maximum: float) -> float:
    if isinstance(value, bool):
        raise ConfigurationError(f"'{name}' must be a number.")
    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"'{name}' must be a number.") from exc
    if not minimum <= parsed <= maximum:
        raise ConfigurationError(f"'{name}' must be between {minimum} and {maximum}.")
    return parsed


def sanitize_component(value: str) -> str:
    """Turn a tag into a stable Windows-safe folder component."""
    cleaned = "".join("_" if char in '<>:"/\\|?*' or ord(char) < 32 else char for char in value)
    cleaned = cleaned.rstrip(" .") or "_unnamed"
    if cleaned.upper() in WINDOWS_RESERVED_NAMES:
        cleaned = f"_{cleaned}"
    return cleaned[:180]


def load_settings(config_path: Path) -> Settings:
    if not config_path.exists():
        raise ConfigurationError(
            f"Configuration file not found: {config_path}\n"
            "Run setup.ps1 or copy config.example.json to config.json."
        )

    try:
        raw = json.loads(config_path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"Invalid JSON in {config_path}: {exc}") from exc
    root = _as_mapping(raw, "configuration")

    output_value = str(root.get("output_directory", "")).strip()
    if not output_value:
        raise ConfigurationError("'output_directory' cannot be blank.")
    output_directory = Path(os.path.expanduser(os.path.expandvars(output_value))).resolve()

    api = _as_mapping(root.get("api", {}), "api")
    api_base_url = str(api.get("base_url", "https://api.rule34.xxx/index.php")).strip()
    parsed_base = urllib.parse.urlparse(api_base_url)
    if parsed_base.scheme != "https" or not parsed_base.netloc:
        raise ConfigurationError("'api.base_url' must be a complete HTTPS URL.")
    api_user_id = str(api.get("user_id", "")).strip()
    api_key = str(api.get("api_key", "")).strip()
    if bool(api_user_id) != bool(api_key):
        raise ConfigurationError("'api.user_id' and 'api.api_key' must either both be filled in or both be blank.")
    if api_user_id and not api_user_id.isdecimal():
        raise ConfigurationError("'api.user_id' must contain only the numeric user ID, without 'user_id='.")
    lowered_key = api_key.casefold()
    if api_key and ("api_key=" in lowered_key or "user_id=" in lowered_key or "&" in api_key):
        raise ConfigurationError(
            "'api.api_key' must contain only the key value, without '&api_key=' or '&user_id='."
        )

    watched_raw = _as_mapping(root.get("watched_tags", {}), "watched_tags")
    watched_tags: list[WatchedTag] = []
    seen: set[tuple[str, str]] = set()
    for category in CATEGORY_NAMES:
        values = watched_raw.get(category, [])
        if not isinstance(values, list):
            raise ConfigurationError(f"'watched_tags.{category}' must be a JSON array.")
        for value in values:
            tag = str(value).strip()
            if not tag:
                continue
            key = (category, tag.casefold())
            if key not in seen:
                watched_tags.append(WatchedTag(category, tag))
                seen.add(key)

    scan = _as_mapping(root.get("scan", {}), "scan")
    downloads = _as_mapping(root.get("downloads", {}), "downloads")
    raw_extensions = downloads.get("allowed_extensions", list(DEFAULT_ALLOWED_EXTENSIONS))
    if not isinstance(raw_extensions, list) or not raw_extensions:
        raise ConfigurationError("'downloads.allowed_extensions' must be a non-empty JSON array.")
    extensions: list[str] = []
    for item in raw_extensions:
        extension = str(item).strip().lower()
        if not extension.startswith(".") or any(char in extension for char in "/\\?"):
            raise ConfigurationError(f"Invalid allowed extension: {item!r}")
        if extension not in extensions:
            extensions.append(extension)

    return Settings(
        output_directory=output_directory,
        api_base_url=api_base_url,
        api_user_id=api_user_id,
        api_key=api_key,
        watched_tags=tuple(watched_tags),
        results_per_page=_bounded_int(scan.get("results_per_page", 100), "scan.results_per_page", 1, 1000),
        pages_per_check=_bounded_int(scan.get("pages_per_check", 3), "scan.pages_per_check", 1, 50),
        first_run_download_limit_per_tag=_bounded_int(
            scan.get("first_run_download_limit_per_tag", 25),
            "scan.first_run_download_limit_per_tag",
            0,
            1000,
        ),
        max_downloads_per_tag_per_run=_bounded_int(
            scan.get("max_downloads_per_tag_per_run", 100),
            "scan.max_downloads_per_tag_per_run",
            1,
            10000,
        ),
        request_delay_seconds=_bounded_float(
            scan.get("request_delay_seconds", 1.0), "scan.request_delay_seconds", 0.25, 60.0
        ),
        request_timeout_seconds=_bounded_float(
            scan.get("request_timeout_seconds", 45), "scan.request_timeout_seconds", 5.0, 300.0
        ),
        retry_attempts=_bounded_int(scan.get("retry_attempts", 3), "scan.retry_attempts", 1, 10),
        allowed_extensions=tuple(extensions),
        save_sidecar_metadata=bool(downloads.get("save_sidecar_metadata", False)),
    )


def configure_logging(project_dir: Path, verbose: bool = False) -> logging.Logger:
    log_directory = project_dir / "logs"
    log_directory.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("r34_tag_watcher")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    file_handler = RotatingFileHandler(
        log_directory / "watcher.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    logger.addHandler(console_handler)
    return logger


class SingleInstanceLock:
    def __init__(self, path: Path, stale_after_hours: int = 6) -> None:
        self.path = path
        self.stale_after_seconds = stale_after_hours * 3600
        self.acquired = False

    def __enter__(self) -> "SingleInstanceLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            age = time.time() - self.path.stat().st_mtime
            if age > self.stale_after_seconds:
                self.path.unlink(missing_ok=True)
        try:
            descriptor = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise RuntimeError("Another watcher run is already in progress.") from exc
        with os.fdopen(descriptor, "w", encoding="ascii") as handle:
            handle.write(str(os.getpid()))
        self.acquired = True
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.acquired:
            self.path.unlink(missing_ok=True)


class StateDatabase:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS tag_state (
                category TEXT NOT NULL,
                watched_tag TEXT NOT NULL,
                initialized_at TEXT NOT NULL,
                PRIMARY KEY (category, watched_tag)
            );

            CREATE TABLE IF NOT EXISTS tag_posts (
                post_id TEXT NOT NULL,
                category TEXT NOT NULL,
                watched_tag TEXT NOT NULL,
                status TEXT NOT NULL,
                file_path TEXT,
                file_url TEXT,
                md5 TEXT,
                first_seen_at TEXT NOT NULL,
                PRIMARY KEY (post_id, category, watched_tag)
            );

            CREATE INDEX IF NOT EXISTS idx_tag_posts_post_status
                ON tag_posts (post_id, status);

            CREATE TABLE IF NOT EXISTS post_files (
                post_id TEXT PRIMARY KEY,
                canonical_path TEXT NOT NULL,
                file_url TEXT,
                md5 TEXT,
                size_bytes INTEGER NOT NULL,
                downloaded_at TEXT NOT NULL
            );
            """
        )
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def __enter__(self) -> "StateDatabase":
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    def is_initialized(self, watched: WatchedTag) -> bool:
        row = self.connection.execute(
            "SELECT 1 FROM tag_state WHERE category = ? AND watched_tag = ?",
            (watched.category, watched.tag),
        ).fetchone()
        return row is not None

    def mark_initialized(self, watched: WatchedTag) -> None:
        self.connection.execute(
            "INSERT OR IGNORE INTO tag_state(category, watched_tag, initialized_at) VALUES (?, ?, ?)",
            (watched.category, watched.tag, utc_now()),
        )
        self.connection.commit()

    def has_record(self, post_id: str, watched: WatchedTag) -> bool:
        row = self.connection.execute(
            """
            SELECT status, file_path FROM tag_posts
            WHERE post_id = ? AND category = ? AND watched_tag = ?
            """,
            (post_id, watched.category, watched.tag),
        ).fetchone()
        if row is None:
            return False
        if row["status"] in {"downloaded", "copied", "linked"}:
            file_path = str(row["file_path"] or "").strip()
            return bool(file_path and is_nonempty_file(Path(file_path)))
        return True

    def get_status(self, post_id: str, watched: WatchedTag) -> str | None:
        row = self.connection.execute(
            "SELECT status FROM tag_posts WHERE post_id = ? AND category = ? AND watched_tag = ?",
            (post_id, watched.category, watched.tag),
        ).fetchone()
        return str(row["status"]) if row is not None else None

    def record(
        self,
        post: Mapping[str, Any],
        watched: WatchedTag,
        status: str,
        file_path: Path | None = None,
    ) -> None:
        self.connection.execute(
            """
            INSERT OR REPLACE INTO tag_posts(
                post_id, category, watched_tag, status, file_path, file_url, md5, first_seen_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(post.get("id", "")),
                watched.category,
                watched.tag,
                status,
                str(file_path) if file_path else None,
                str(post.get("file_url", "")),
                str(post.get("md5", "")),
                utc_now(),
            ),
        )
        self.connection.commit()

    def find_existing_file(self, post_id: str) -> Path | None:
        canonical = self.connection.execute(
            "SELECT canonical_path FROM post_files WHERE post_id = ?",
            (post_id,),
        ).fetchone()
        if canonical is not None:
            candidate = Path(canonical["canonical_path"])
            if is_nonempty_file(candidate):
                return candidate

        rows = self.connection.execute(
            """
            SELECT file_path FROM tag_posts
            WHERE post_id = ? AND status IN ('downloaded', 'copied', 'linked')
            """,
            (post_id,),
        ).fetchall()
        for row in rows:
            if row["file_path"]:
                candidate = Path(row["file_path"])
                if is_nonempty_file(candidate):
                    return candidate
        return None

    def record_post_file(self, post: Mapping[str, Any], canonical_path: Path) -> None:
        self.connection.execute(
            """
            INSERT OR REPLACE INTO post_files(
                post_id, canonical_path, file_url, md5, size_bytes, downloaded_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                str(post.get("id", "")),
                str(canonical_path),
                str(post.get("file_url", "")),
                str(post.get("md5", "")),
                canonical_path.stat().st_size,
                utc_now(),
            ),
        )
        self.connection.commit()


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def is_nonempty_file(path: Path) -> bool:
    try:
        return path.is_file() and path.stat().st_size > 0
    except OSError:
        return False


def verify_hard_link_support(output_directory: Path) -> None:
    """Confirm that the selected archive volume supports real hard links."""
    test_directory = output_directory / ".r34-watcher" / "hardlink-test"
    test_directory.mkdir(parents=True, exist_ok=True)
    source: Path | None = None
    link: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=test_directory, prefix="source_", delete=False) as handle:
            handle.write(b"hard-link-test")
            source = Path(handle.name)
        link = source.with_name(source.name + ".link")
        os.link(source, link)
        if not os.path.samefile(source, link):
            raise OSError("The filesystem created two different files instead of a hard link.")
    except OSError as exc:
        raise ConfigurationError(
            "The output folder must be on a filesystem that supports hard links "
            "(normally NTFS on Windows). Choose an NTFS drive or folder. "
            f"Hard-link test failed: {exc}"
        ) from exc
    finally:
        if link is not None:
            link.unlink(missing_ok=True)
        if source is not None:
            source.unlink(missing_ok=True)
        try:
            test_directory.rmdir()
        except OSError:
            pass


class Rule34Api:
    def __init__(self, settings: Settings, logger: logging.Logger) -> None:
        self.settings = settings
        self.logger = logger
        self.last_request_at = 0.0

    def _wait_for_rate_limit(self) -> None:
        elapsed = time.monotonic() - self.last_request_at
        delay = self.settings.request_delay_seconds - elapsed
        if delay > 0:
            time.sleep(delay)

    def build_posts_url(self, tag: str, page: int) -> str:
        parameters = {
            "page": "dapi",
            "s": "post",
            "q": "index",
            "json": "1",
            "limit": str(self.settings.results_per_page),
            "pid": str(page),
            "tags": tag,
        }
        if self.settings.api_user_id:
            parameters["user_id"] = self.settings.api_user_id
        if self.settings.api_key:
            parameters["api_key"] = self.settings.api_key
        return f"{self.settings.api_base_url}?{urllib.parse.urlencode(parameters)}"

    def _decode_posts_response(self, payload: bytes) -> list[Any] | Mapping[str, Any]:
        """Decode normal, message-only, and accidentally double-encoded JSON."""
        try:
            response: Any = json.loads(payload.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            excerpt = payload[:160].decode("utf-8", errors="replace")
            raise ApiError(f"API returned non-JSON data: {excerpt!r}") from exc

        # Some API/proxy paths return JSON as a quoted JSON string. Unwrap it
        # once so a valid list still works, while retaining plain-text messages.
        if isinstance(response, str):
            message = response.strip()
            if message.startswith(("[", "{")):
                try:
                    response = json.loads(message)
                except json.JSONDecodeError:
                    pass

        if isinstance(response, str):
            message = response.strip()
            normalized = message.casefold().rstrip(".! ")
            if normalized in {"no images found", "no posts found", "nothing found"}:
                return []
            if self.settings.api_key:
                message = message.replace(self.settings.api_key, "[redacted API key]")
            if not message:
                message = "(blank message)"
            raise ApiError(f"API returned message: {message[:500]}")

        if isinstance(response, Mapping) or isinstance(response, list):
            return response
        raise ApiError(f"Unexpected API response type: {type(response).__name__}")

    def _request_bytes(self, url: str) -> bytes:
        last_error: Exception | None = None
        for attempt in range(1, self.settings.retry_attempts + 1):
            self._wait_for_rate_limit()
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": f"R34TagWatcher/{VERSION} (personal local archiver)",
                    "Accept": "application/json, application/octet-stream;q=0.9, */*;q=0.8",
                },
            )
            try:
                with urllib.request.urlopen(request, timeout=self.settings.request_timeout_seconds) as response:
                    payload = response.read()
                self.last_request_at = time.monotonic()
                return payload
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                self.last_request_at = time.monotonic()
                last_error = exc
                if attempt < self.settings.retry_attempts:
                    pause = min(2 ** (attempt - 1), 15)
                    self.logger.warning("Request failed (attempt %s); retrying in %ss: %s", attempt, pause, exc)
                    time.sleep(pause)
        raise ApiError(f"Request failed after {self.settings.retry_attempts} attempts: {last_error}")

    def fetch_posts_page(self, watched: WatchedTag, page: int) -> list[Mapping[str, Any]]:
        url = self.build_posts_url(watched.tag, page)
        payload = self._request_bytes(url)
        response = self._decode_posts_response(payload)
        if isinstance(response, Mapping):
            message: Any = response.get("message") or response.get("reason") or response
            message_text = str(message)
            if self.settings.api_key:
                message_text = message_text.replace(self.settings.api_key, "[redacted API key]")
            raise ApiError(f"API rejected the request: {message_text}")
        valid_page = [item for item in response if isinstance(item, Mapping) and str(item.get("id", ""))]
        return sorted(valid_page, key=post_sort_key, reverse=True)

    def fetch_posts(self, watched: WatchedTag) -> list[Mapping[str, Any]]:
        posts_by_id: dict[str, Mapping[str, Any]] = {}
        for page in range(self.settings.pages_per_check):
            valid_page = self.fetch_posts_page(watched, page)
            for post in valid_page:
                posts_by_id[str(post["id"])] = post
            if len(valid_page) < self.settings.results_per_page:
                break

        return sorted(posts_by_id.values(), key=post_sort_key, reverse=True)

    def download_to(self, url: str, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = self._request_bytes(url)
        if not payload:
            raise ApiError("Downloaded file was empty.")
        destination.write_bytes(payload)


def post_sort_key(post: Mapping[str, Any]) -> tuple[int, str]:
    post_id = str(post.get("id", ""))
    try:
        return int(post_id), post_id
    except ValueError:
        return -1, post_id


def normalize_file_url(value: Any, api_base_url: str) -> str:
    url = str(value or "").strip()
    if url.startswith("//"):
        return f"https:{url}"
    if url.startswith("/"):
        parsed = urllib.parse.urlparse(api_base_url)
        return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, url, "", "", ""))
    return url


def file_extension_from_url(url: str) -> str:
    suffix = Path(urllib.parse.unquote(urllib.parse.urlparse(url).path)).suffix.lower()
    return suffix if 1 < len(suffix) <= 10 else ""


def build_filename(post: Mapping[str, Any], extension: str) -> str:
    post_id = sanitize_component(str(post.get("id", "unknown")))
    md5 = str(post.get("md5", "")).strip().lower()
    if len(md5) != 32 or any(char not in "0123456789abcdef" for char in md5):
        source = str(post.get("file_url", ""))
        md5 = hashlib.sha256(source.encode("utf-8")).hexdigest()[:16]
    return f"{post_id}_{md5}{extension}"


class Archive:
    def __init__(
        self,
        settings: Settings,
        state: StateDatabase,
        api: Rule34Api,
        logger: logging.Logger,
        dry_run: bool = False,
    ) -> None:
        self.settings = settings
        self.state = state
        self.api = api
        self.logger = logger
        self.dry_run = dry_run

    def destination_for(self, watched: WatchedTag, filename: str) -> Path:
        return (
            self.settings.output_directory
            / watched.category_folder
            / sanitize_component(watched.tag)
            / filename
        )

    def canonical_for(self, post_id: str, filename: str) -> Path:
        shard = hashlib.sha256(post_id.encode("utf-8")).hexdigest()[:2]
        return self.settings.output_directory / ".r34-watcher" / "files" / shard / filename

    def _ensure_hard_link(self, source: Path, destination: Path) -> bool:
        """Create a hard link, returning False when the correct link already exists."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.link(source, destination)
            return True
        except FileExistsError:
            try:
                if os.path.samefile(source, destination):
                    return False
            except OSError:
                pass
            raise OSError(
                f"Refusing to replace an unrelated existing file: {destination}"
            )
        except OSError as exc:
            raise OSError(
                f"Could not create a hard link at {destination}. The archive must stay on "
                f"one NTFS volume and the drive must support hard links: {exc}"
            ) from exc

    def _write_metadata(self, destination: Path, post: Mapping[str, Any], watched: WatchedTag) -> None:
        if not self.settings.save_sidecar_metadata:
            return
        sidecar = destination.with_suffix(destination.suffix + ".json")
        metadata = {
            "archived_at": utc_now(),
            "matched_category": watched.category,
            "matched_tag": watched.tag,
            "post": dict(post),
        }
        sidecar.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")

    def process_post(
        self,
        post: Mapping[str, Any],
        watched: WatchedTag,
        include_baseline_skipped: bool = False,
    ) -> RunSummary:
        summary = RunSummary()
        post_id = str(post.get("id", ""))
        if not post_id:
            summary.errors += 1
            return summary
        existing_status = self.state.get_status(post_id, watched)

        file_url = normalize_file_url(post.get("file_url"), self.settings.api_base_url)
        extension = file_extension_from_url(file_url)
        if not file_url.startswith("https://"):
            self.logger.warning("Post %s has no usable HTTPS file URL; skipped", post_id)
            self.state.record(post, watched, "invalid_url")
            summary.errors += 1
            return summary
        if extension not in self.settings.allowed_extensions:
            self.logger.info("Post %s uses filtered extension %s", post_id, extension or "(none)")
            self.state.record(post, watched, "filtered_extension")
            summary.skipped_extension += 1
            return summary

        filename = build_filename(post, extension)
        destination = self.destination_for(watched, filename)
        if existing_status is not None and not (
            include_baseline_skipped and existing_status == "baseline_skipped"
        ):
            if existing_status not in {"downloaded", "copied", "linked"} or is_nonempty_file(destination):
                summary.already_processed += 1
                return summary
        if self.dry_run:
            self.logger.info("DRY RUN: would store post %s once and link it at %s", post_id, destination)
            return summary

        canonical = self.canonical_for(post_id, filename)
        canonical.parent.mkdir(parents=True, exist_ok=True)
        existing = self.state.find_existing_file(post_id)
        try:
            if not is_nonempty_file(canonical):
                if existing is not None:
                    self._ensure_hard_link(existing, canonical)
                else:
                    temp_root = self.settings.output_directory / ".r34-watcher" / "temp"
                    temp_root.mkdir(parents=True, exist_ok=True)
                    with tempfile.NamedTemporaryFile(
                        dir=temp_root, prefix=f"{post_id}_", suffix=".part", delete=False
                    ) as handle:
                        temp_path = Path(handle.name)
                    try:
                        self.api.download_to(file_url, temp_path)
                        if not is_nonempty_file(temp_path):
                            raise ApiError("Downloaded file was empty.")
                        os.replace(temp_path, canonical)
                        summary.downloaded += 1
                    finally:
                        temp_path.unlink(missing_ok=True)

            self.state.record_post_file(post, canonical)
            created = self._ensure_hard_link(canonical, destination)

            self._write_metadata(destination, post, watched)
            self.state.record(post, watched, "linked", destination)
            if created:
                summary.linked += 1
            else:
                summary.already_processed += 1
            action = "Downloaded and linked" if summary.downloaded else "Linked"
            self.logger.info("%s post %s into %s/%s", action, post_id, watched.category_folder, watched.tag)
        except (ApiError, OSError) as exc:
            self.logger.error("Could not archive post %s for %s/%s: %s", post_id, watched.category, watched.tag, exc)
            summary.errors += 1
        return summary

    def process_tag(self, watched: WatchedTag) -> RunSummary:
        summary = RunSummary()
        self.logger.info("Checking %s tag: %s", watched.category, watched.tag)
        posts = self.api.fetch_posts(watched)
        initialized = self.state.is_initialized(watched)
        unseen = [post for post in posts if not self.state.has_record(str(post.get("id", "")), watched)]

        if not initialized:
            limit = self.settings.first_run_download_limit_per_tag
            selected = unseen[:limit]
            baseline = unseen[limit:]
            self.logger.info(
                "First check for %s/%s: downloading up to %s newest post(s), baselining %s older post(s)",
                watched.category,
                watched.tag,
                limit,
                len(baseline),
            )
            for post in baseline:
                if not self.dry_run:
                    self.state.record(post, watched, "baseline_skipped")
                summary.skipped_baseline += 1
        else:
            selected = unseen[: self.settings.max_downloads_per_tag_per_run]
            if len(unseen) > len(selected):
                self.logger.warning(
                    "%s unseen posts found for %s/%s; %s deferred until a later run",
                    len(unseen),
                    watched.category,
                    watched.tag,
                    len(unseen) - len(selected),
                )

        for post in reversed(selected):
            summary.absorb(self.process_post(post, watched))

        if not initialized and not self.dry_run:
            self.state.mark_initialized(watched)
        return summary

    def backfill_tag(self, watched: WatchedTag) -> RunSummary:
        """Walk every result page and archive posts skipped by normal initialization."""
        summary = RunSummary()
        page = 0
        pages_fetched = 0
        previous_signature: tuple[str, ...] | None = None
        self.logger.info("Starting historical backfill for %s/%s", watched.category, watched.tag)
        if not self.dry_run:
            self.state.mark_initialized(watched)

        while True:
            posts = self.api.fetch_posts_page(watched, page)
            if not posts:
                break
            pages_fetched += 1

            signature = tuple(str(post.get("id", "")) for post in posts)
            if signature == previous_signature:
                raise ApiError(
                    f"API repeated page {page} while backfilling {watched.tag}; stopped to avoid a loop"
                )
            previous_signature = signature
            self.logger.info(
                "Backfill %s/%s: page %s, %s post(s)",
                watched.category,
                watched.tag,
                page + 1,
                len(posts),
            )

            # Oldest first within each page gives a predictable archive order.
            for post in reversed(posts):
                summary.absorb(
                    self.process_post(post, watched, include_baseline_skipped=True)
                )

            if len(posts) < self.settings.results_per_page:
                break
            page += 1

        self.logger.info(
            "Historical backfill completed for %s/%s after %s page(s)",
            watched.category,
            watched.tag,
            pages_fetched,
        )
        return summary

    def run(self, backfill: bool = False) -> RunSummary:
        total = RunSummary()
        if not self.settings.watched_tags:
            self.logger.warning("No watched tags are configured. Run setup.ps1 or edit config.json.")
            return total
        for watched in self.settings.watched_tags:
            try:
                operation = self.backfill_tag if backfill else self.process_tag
                total.absorb(operation(watched))
            except ApiError as exc:
                total.errors += 1
                label = "backfill" if backfill else "check"
                self.logger.error("API %s failed for %s/%s: %s", label, watched.category, watched.tag, exc)
        return total


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help="Path to config.json")
    parser.add_argument("--dry-run", action="store_true", help="Query posts and show destinations without downloading")
    parser.add_argument(
        "--backfill",
        action="store_true",
        help="Download all historical posts for every configured tag; safe to rerun",
    )
    parser.add_argument("--check-config", action="store_true", help="Validate configuration without contacting the site")
    parser.add_argument("--verbose", action="store_true", help="Show detailed logging")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    logger = configure_logging(PROJECT_DIR, args.verbose)
    try:
        settings = load_settings(args.config.resolve())
    except ConfigurationError as exc:
        logger.error("Configuration error: %s", exc)
        return 2

    if args.check_config:
        try:
            verify_hard_link_support(settings.output_directory)
        except ConfigurationError as exc:
            logger.error("Storage compatibility error: %s", exc)
            return 2
        print(
            f"Configuration is valid. {len(settings.watched_tags)} watched tag(s) configured. "
            "The output folder supports hard links."
        )
        return 0

    runtime_directory = settings.output_directory / ".r34-watcher"
    try:
        with SingleInstanceLock(runtime_directory / "watcher.lock"):
            with StateDatabase(runtime_directory / "state.sqlite3") as state:
                api = Rule34Api(settings, logger)
                summary = Archive(settings, state, api, logger, dry_run=args.dry_run).run(
                    backfill=args.backfill
                )
    except RuntimeError as exc:
        logger.warning("%s", exc)
        return 0
    except OSError as exc:
        logger.exception("Local filesystem error: %s", exc)
        return 1

    logger.info(
        "%s finished: %s downloaded, %s tag links created, %s already processed, %s baseline-skipped, "
        "%s extension-filtered, %s errors",
        "Backfill" if args.backfill else "Watcher",
        summary.downloaded,
        summary.linked,
        summary.already_processed,
        summary.skipped_baseline,
        summary.skipped_extension,
        summary.errors,
    )
    return 1 if summary.errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
