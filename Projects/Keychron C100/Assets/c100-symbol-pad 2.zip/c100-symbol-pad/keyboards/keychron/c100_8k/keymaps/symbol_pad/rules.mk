UNICODE_COMMON = yes
UNICODE_ENABLE = yes
VIA_ENABLE = no

# Keychron's C100 source currently has a known GCC warning in an RGB effect.
CFLAGS += -Wno-error=unused-but-set-variable
