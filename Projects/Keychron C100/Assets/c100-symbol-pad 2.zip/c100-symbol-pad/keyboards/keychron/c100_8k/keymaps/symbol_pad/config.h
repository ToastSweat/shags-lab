#pragma once

// This project is intentionally Windows-only for now.
#define UNICODE_SELECTED_MODES UNICODE_MODE_WINDOWS
#define UNICODE_CYCLE_PERSIST false
