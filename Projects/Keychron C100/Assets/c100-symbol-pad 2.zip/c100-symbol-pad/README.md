# Keychron C100 8K Symbol Pad

Custom QMK userspace for turning the Keychron C100 8K into a 100-key Unicode symbol keyboard.

## Important

Start with the `unicode_test` firmware. Do **not** flash the full 100-key map first.

The test firmware maps:
- top-left physical key -> ©
- top-right physical key -> QK_BOOT (return to bootloader)
- all other keys -> disabled

Once © works in Notepad, build and flash the full `symbol_pad` firmware.

## Windows prerequisite

QMK's Windows Unicode mode uses Windows HexNumpad input. Enable it once:

    reg add "HKCU\Control Panel\Input Method" /v EnableHexNumpad /t REG_SZ /d 1 /f

Then sign out/in or reboot.

## Clone QMK

Use Keychron's fork and the 2025q3 branch because that branch contains C100 8K support:

    git clone --branch 2025q3 --recurse-submodules https://github.com/Keychron/qmk_firmware.git

Place this project next to it, for example:

    ~/c100-dev/
      qmk_firmware/
      c100-symbol-pad/

## Build the safe test

From this project directory:

    make test QMK_HOME=../qmk_firmware

Expected firmware name should be similar to:

    keychron_c100_8k_unicode_test.bin

## Full map

After the test works:

    make full QMK_HOME=../qmk_firmware

Expected firmware name should be similar to:

    keychron_c100_8k_symbol_pad.bin

## Flash/recovery

Only flash a binary built for `keychron/c100_8k`.

Known C100 8K bootloader entry methods:
- Hold the top-left physical key while plugging in USB.
- Or use the physical reset button under the spacebar-position area of the PCB.

The test firmware also puts `QK_BOOT` on the top-right key for convenience.

## Full 10x10 layout

    © ® ™ ℠ ℗ § ¶ № † ‡
    ¢ £ € ¥ ₹ ₩ ₽ ₺ ₴ ₿
    ± × ÷ ≠ ≈ ≤ ≥ ∞ √ ∫
    ∑ ∏ ∂ ∆ π µ Ω λ α β
    ° ‰ ¹ ² ³ ⁰ ½ ¼ ¾ ⌀
    … • · – — ‐ “ ” ‘ ’
    ← ↑ → ↓ ↔ ↕ ↖ ↗ ↘ ↙
    ⇐ ⇒ ⇑ ⇓ ↩ ↪ ↺ ↻ ⤴ ⤵
    ✓ ✔ ✕ ✖ ☑ ☐ ☒ ★ ☆ ※
    ♠ ♥ ♦ ♣ ♪ ♫ ☺ ☹ ♂ ♀
